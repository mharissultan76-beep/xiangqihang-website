(() => {
  const langToggle = document.getElementById('langToggle');
  let language = 'en';
  const applyLanguage = () => {
    document.documentElement.lang = language;
    document.querySelectorAll('[data-en][data-zh]').forEach(el => {
      const value = el.getAttribute(language === 'en' ? 'data-en' : 'data-zh');
      if (value !== null) el.innerHTML = value;
    });
    document.querySelectorAll('[data-en-category][data-zh-category]').forEach(el => {
      el.dataset.category = language === 'en' ? el.dataset.enCategory : el.dataset.zhCategory;
    });
    langToggle.textContent = language === 'en' ? '中文' : 'English';
  };
  langToggle.addEventListener('click', () => { language = language === 'en' ? 'zh' : 'en'; applyLanguage(); });
  const menuBtn = document.getElementById('menuBtn');
  const nav = document.getElementById('navLinks');
  menuBtn.addEventListener('click', () => nav.classList.toggle('open'));
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
  document.querySelectorAll('.filter').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach(b => b.classList.remove('active'));
    button.classList.add('active');
    const filter = button.dataset.filter;
    document.querySelectorAll('.category').forEach(card => card.classList.toggle('hidden', filter !== 'all' && card.dataset.group !== filter));
  }));
  document.querySelectorAll('.inquiryCategory').forEach(button => button.addEventListener('click', () => {
    const select = document.getElementById('quoteCategory');
    const category = language === 'en' ? button.dataset.category : button.dataset.zhCategory;
    const options = Array.from(select.options);
    const match = options.find(option => option.text.toLowerCase().includes(category.toLowerCase()));
    if (match) select.value = match.value;
    else select.value = 'Other / 其他';
    document.getElementById('contact').scrollIntoView({behavior:'smooth'});
  }));
  document.getElementById('quoteForm').addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const subject = `Xiangqihang B2B inquiry — ${data.get('category')}`;
    const body = [
      `Name: ${data.get('name')}`, `Business email: ${data.get('email')}`, `Company: ${data.get('company') || 'Not provided'}`,
      `Destination: ${data.get('country')}`, `Category: ${data.get('category')}`, `Quantity: ${data.get('quantity') || 'Not provided'}`,
      '', 'Specifications / project details:', data.get('details')
    ].join('\n');
    // Replace this placeholder with the verified company inbox or connect a secure form endpoint before publishing.
    const recipient = 'REPLACE_WITH_COMPANY_EMAIL';
    const status = document.getElementById('formStatus');
    if (recipient === 'REPLACE_WITH_COMPANY_EMAIL') {
      status.textContent = language === 'en'
        ? 'Demo mode: form details are ready, but the company email has not been configured. Add the verified recipient in script.js before launch.'
        : '演示模式：询盘内容已准备好，但尚未配置公司邮箱。正式上线前请在 script.js 中填写已验证的收件邮箱。';
      const blob = new Blob([`Subject: ${subject}\n\n${body}`], {type:'text/plain'});
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a'); link.href = url; link.download = 'xiangqihang-inquiry-draft.txt'; link.click(); URL.revokeObjectURL(url);
      return;
    }
    window.location.href = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  });
  document.getElementById('year').textContent = new Date().getFullYear();
  applyLanguage();
})();
