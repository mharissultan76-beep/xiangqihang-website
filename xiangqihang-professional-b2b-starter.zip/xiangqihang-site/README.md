# Xiangqihang Export Website — Starter

A responsive, bilingual (English / Simplified Chinese) static B2B export website concept for 临沂祥启航进出口贸易有限公司.

## Included
- Responsive corporate homepage and mobile navigation
- Product category browsing and filters
- 13 proposed export-oriented product categories
- English / Simplified Chinese toggle
- Quote inquiry form fields for contact, destination, category, quantity and requirements
- Manufacturing, factory sourcing and export support sections
- No WhatsApp integration

## Important before publishing
1. Replace `REPLACE_WITH_COMPANY_EMAIL` in `script.js` with a verified company inbox, or connect a secure server-side form endpoint. The current form is demo-only: it downloads an inquiry draft text file until the recipient is configured.
2. Replace stock image URLs with licensed, accurate product and factory photos. Some images are illustrative and may not precisely depict the products listed.
3. Verify each product category, actual manufacturing capability, supplier authorization, specifications, MOQ, certificates, lead times and export compliance before making claims.
4. Add the real company address, telephone/email, legal and privacy pages, cookie disclosures if applicable, and a secure backend/CMS for production use.
5. The site currently uses Google Fonts and Unsplash-hosted image URLs, requiring internet access. Self-host licensed assets for a more controlled production deployment.

## Preview locally
Open `index.html` in a modern browser. Some browser restrictions may affect external assets when opened as a local file; use a local static server for best results.

## Deploy
Upload the contents of this folder to a static host such as GitHub Pages, Netlify, or your company hosting. This package is a starter source, not a deployed live website.
